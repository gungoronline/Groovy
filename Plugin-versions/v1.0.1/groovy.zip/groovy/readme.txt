Plugin Name: Groovy RESTFUL API
Description:  Create useful Android App for your Wordpress Website in 1 minute. Create app free for Non commercial on <a href="http://apkcreate.com" target="_blank">ApkCreate.com</a> Also Your website address in <a href="https://play.google.com/store/apps/details?id=com.serifgungor.linker">Linker Android App</a>. You can see your wordpress blogs and visitors from this application. 
Version: 1.0.0
Author: GUNGORONLINE
Author URI: https://gungor.online/pages/wordpress-plugins
License: GNU