<?php
/*
Plugin Name: Groovy RESTFUL API
Description:  Your website address in <a href="https://play.google.com/store/apps/details?id=com.serifgungor.linker">Linker Android App</a>. You can see your wordpress blogs and visitors from this application. 
Version: 1.0.0
Author: GUNGORONLINE
Author URI: https://github.com/gungoronline/Groovy
License: GNU
*/

global $wpdb;
global $wp;  

//require WP_PLUGIN_DIR . '/groovy/spp.php';

function jss() {
    global $wpdb;
    global $wp;  
	
	
	
$lang=substr(@$_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2); //gelen dil
$date = date("y-m-d H:i:s"); //gelen zaman
$refer = $_SERVER['REQUEST_URI']; //istek yapılan sayfa
$ref = $_SERVER['HTTP_REFERER']; //nereden gelindi
$domain = "";

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

if(strstr($ref,"http:")){
	preg_match('@^(?:http://)?([^/]+)@i', $ref, $matches);
	$domain = $matches[1];
}else if(strstr($ref,"https:")){
	preg_match('@^(?:https://)?([^/]+)@i', $ref, $matches);
	$domain = $matches[1];
}

$table = $wpdb->prefix.'analyse_referancelogs';
$data = array('visitor_refer_domain' => $domain, 'visitor_refer_url' => $ref,'visitor_current_page' => $refer,'visitor_visit_date' => $date,'visitor_ip'=>$ip,'visitor_lang'=>$lang);
$format = array('%s','%d');
$wpdb->insert($table,$data,$format);
$my_id = $wpdb->insert_id;
	
	//echo( $wp->query_vars['name']);
	//var_dump($wp);
	if($wp->query_vars['name']!="NULL" && $wp->query_vars['name']!=""){
		if(strstr($wp->request,"content/api/post")==null){
			//update blog viewcount
			$res = $wpdb->get_results ("SELECT * FROM  {$wpdb->base_prefix}posts WHERE post_name='".$wp->query_vars['name']."'");
			foreach ( $res as $page )
			{
				$sql = "INSERT IGNORE INTO {$wpdb->base_prefix}post_viewcounts (post_id,post_parent_id, view_count, last_view_timestamp)
					VALUES ('".$page->ID."','".$page->post_parent."', '0', '0');";
				$wpdb->query($sql);
				
				$sql2 = "UPDATE {$wpdb->base_prefix}post_viewcounts SET view_count = view_count+1,last_view_timestamp = '' WHERE id = ".$page->ID.";";
				$wpdb->query($sql2);
			}
		}
	}else if($wp->query_vars['pagename']!="NULL" && $wp->query_vars['pagename']!=""){
		if(strstr($wp->request,"content/api/post")==null){
			//update blog viewcount
			$res = $wpdb->get_results ("SELECT * FROM  {$wpdb->base_prefix}posts WHERE post_name='".$wp->query_vars['pagename']."'");
			foreach ( $res as $page )
			{
				$sql = "INSERT IGNORE INTO {$wpdb->base_prefix}post_viewcounts (post_id,post_parent_id, view_count, last_view_timestamp)
					VALUES ('".$page->ID."','".$page->post_parent."', '0', '0');";
				$wpdb->query($sql);
				
				$sql2 = "UPDATE {$wpdb->base_prefix}post_viewcounts SET view_count = view_count+1,last_view_timestamp = '' WHERE id = ".$page->ID.";";
				$wpdb->query($sql2);
			}
		}
	}
	
	if("content/api/post/blogs.php"==$wp->request){

		$qs = "SELECT * FROM ".$wpdb->posts." WHERE post_status='publish' and post_type='post'";
		
		$q = $wpdb->prepare($qs, $postType, $year, $month);
		$posts = $wpdb->get_results($q,ARRAY_A);
		
		
		$json = array();
		for($i=0; $i<count($posts); $i++){
			$itemObject = new stdClass();
			$itemObject->id = $posts[$i]['ID'];
			$thumb = $wpdb->get_var("SELECT guid FROM ".$wpdb->posts." where post_parent = '".$posts[$i]['ID']."' and post_type = 'attachment'");
			$cnt = $wpdb->get_var("SELECT SUM(view_count) as res FROM {$wpdb->base_prefix}post_viewcounts where post_parent_id=".$posts[$i]['post_parent']);
			$itemObject->sharetime = $posts[$i]['post_date'];
			$itemObject->updatetime = $posts[$i]['post_modified'];
			$itemObject->blog_do_viewcount = $cnt;
			$itemObject->url = $posts[$i]['guid'];
			$itemObject->image =$thumb;
			$itemObject->blog_seo_title = $posts[$i]['post_title'];
			array_push($json, $itemObject);
		}
			
		$response = array('blogs' => $json);
		echo json_encode($response, JSON_PRETTY_PRINT);
		header('Content-Type: application/json');
		die();
	}
	if("content/api/post/pages.php"==$wp->request){
		$qs = "SELECT * FROM ".$wpdb->posts." WHERE post_status='publish' and post_type='page'";
		$q = $wpdb->prepare($qs, $postType, $year, $month);
		$posts = $wpdb->get_results($q,ARRAY_A);
		
		$json = array();
		for($i=0; $i<count($posts); $i++){
			$itemObject = new stdClass();
			$itemObject->id = $posts[$i]['ID'];
			$itemObject->page_share_time = $posts[$i]['post_date'];
			$itemObject->page_lastview = $posts[$i]['post_modified'];
			$cnt = $wpdb->get_var("SELECT SUM(view_count) as res FROM {$wpdb->base_prefix}post_viewcounts where post_parent_id=".$posts[$i]['post_parent']);
			$itemObject->page_view_count = $cnt;
			$itemObject->page_url = $posts[$i]['guid'];
			$itemObject->page_title = $posts[$i]['post_title'];
			array_push($json, $itemObject);
		}

		$response = array('pages' => $json);
		echo json_encode($response, JSON_PRETTY_PRINT);
		header('Content-Type: application/json');
		die();
	}
	if("content/api/post/categories.php"==$wp->request){
		$qs = "SELECT * FROM ".$wpdb->terms;
		$q = $wpdb->prepare($qs, $postType, $year, $month);
		$posts = $wpdb->get_results($q,ARRAY_A);
		
		$json = array();
		for($i=0; $i<count($posts); $i++){
			$itemObject = new stdClass();
			$itemObject->id = $posts[$i]['term_id'];
			$itemObject->parent = 0;
			$itemObject->ranking_id = 0;
			$itemObject->category_name = $posts[$i]['name'];
			$itemObject->category_link = $posts[$i]['slug'];
			array_push($json, $itemObject);
		}

		$response = array('categories' => $json);
		echo json_encode($response, JSON_PRETTY_PRINT);
		header('Content-Type: application/json');
		die();
	}
	if("content/api/post/images.php"==$wp->request){
		
		$dir = "wp-content/uploads/2020";
		function tarih ($dosya) { 
			return "";//date("d.m.Y H:i:s", filectime($dosya));
		} 
		$limit = 100;

		$ffs = scandir($dir);
		$json = array();
		$cnt = 0;
		foreach($ffs as $ff){
			if($ff != '.' && $ff != '..' && 'index.php'){
				if(is_dir($dir.'/'.$ff)){
					$dds = scandir($dir.'/'.$ff);
					foreach($dds as $dd){
						if($dd != "." && $dd != ".." && $dd != "index.php"){
							if($cnt<$limit){
								$cnt++;						
								$itemObject = new stdClass();
								$newStr = $dir.'/'.$ff.'/'.$dd;
								$newStr = str_replace("../../../content/","content/",$newStr);
								$itemObject->image_name = $newStr;
								$itemObject->image_created_time = tarih($dd);
								array_push($json, $itemObject);
							}
						}
					}
				}
			}
		}
		$response = array('images' => $json);
		echo json_encode($response, JSON_UNESCAPED_SLASHES);
		
		header('Content-Type: application/json');
		die();
	}
	if("content/api/post/todayOrganicSearch.php"==$wp->request){
		/*
		INSERT INTO `wp_analyse_referancelogs` (`id`, `visitor_refer_domain`, `visitor_refer_url`, `visitor_current_page`, `visitor_visit_date`, `visitor_ip`, `visitor_lang`) VALUES (NULL, 'www.gungor.online', 'http://www.gungor.online/', '/', '18-11-06 17:19:47', '52.53.201.78', '');
		*/
		$qs = "SELECT COUNT(*) as cnt, visitor_refer_domain FROM {$wpdb->base_prefix}analyse_referancelogs WHERE visitor_refer_domain!='' and visitor_visit_date LIKE '%".date('y')."-".date('m')."-".date('d')."%' GROUP BY visitor_refer_domain ORDER BY cnt DESC";
		$q = $wpdb->prepare($qs, $postType, $year, $month);
		$posts = $wpdb->get_results($q,ARRAY_A);
		
		$json = array();
		for($i=0; $i<count($posts); $i++){
			$itemObject = new stdClass();
			$itemObject->cnt = $posts[$i]['cnt'];
			$itemObject->visitor_refer_domain = $posts[$i]['visitor_refer_domain'];
			array_push($json, $itemObject);
		}

		$response = array('todayOrganicSearch' => $json);
		echo json_encode($response, JSON_PRETTY_PRINT);
		header('Content-Type: application/json');
		die();
	}
	if("content/api/post/permission.php"==$wp->request){
		echo '{
    "permission": [
        {
            "indexId": "1",
            "codeName": "statistics"
        },
        {
            "indexId": "2",
            "codeName": "blogs"
        },
        {
            "indexId": "3",
            "codeName": "pages"
        },
        {
            "indexId": "4",
            "codeName": "microblogs"
        }
    ]
		}';
		header('Content-Type: application/json');
		die();
	}

}
add_action( 'template_redirect', 'jss' );
	
register_deactivation_hook( __FILE__, 'my_plugin_remove_database' );
function my_plugin_remove_database() {
    global $wpdb;
    $sql = "DROP TABLE IF EXISTS {$wpdb->base_prefix}analyse_crawlerlogs";
    $wpdb->query($sql);
	
	$sql2 = "DROP TABLE IF EXISTS {$wpdb->base_prefix}analyse_referancelogs";
    $wpdb->query($sql2);
	
	$sql3 = "DROP TABLE IF EXISTS {$wpdb->base_prefix}post_viewcounts";
    $wpdb->query($sql3);
	
	//Must be connection for Webservice Domain with Mobile App !	
	$response = wp_remote_get( 'http://gungor.online/apps/linker/remove_site.php?domain='.get_home_url() );
	if ( is_wp_error( $response ) ) {
	   echo 'There be errors, yo!';
	} else {
	   $body = wp_remote_retrieve_body( $response );
	   $data = json_decode( $body );
	}

	if ( $data->Data ) {
	   print_r( $data->Data );
	}	
} 	

register_activation_hook( __FILE__, 'my_plugin_add_database' );
function my_plugin_add_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	$sql = "CREATE TABLE IF NOT EXISTS `{$wpdb->base_prefix}analyse_crawlerlogs` (
	  id int(11) NOT NULL AUTO_INCREMENT,
	  `crawler_useragent` varchar(255) NOT NULL,
	  `crawler_visit_url` varchar(255) NOT NULL,
	  `crawler_visit_date` varchar(20) NOT NULL,
	  `crawler_visit_ip` varchar(15) NOT NULL,
	  `crawler_lang` varchar(2) NOT NULL,
	  `crawler_name` varchar(40) NOT NULL,
	  PRIMARY KEY  (id)
	) $charset_collate;";
	
	$sql2 = "CREATE TABLE IF NOT EXISTS `{$wpdb->base_prefix}analyse_referancelogs` (
	  `id` int(11) NOT NULL AUTO_INCREMENT,
	  `visitor_refer_domain` varchar(255) NOT NULL,
	  `visitor_refer_url` varchar(255) NOT NULL,
	  `visitor_current_page` varchar(255) NOT NULL,
	  `visitor_visit_date` varchar(20) NOT NULL,
	  `visitor_ip` varchar(15) NOT NULL,
	  `visitor_lang` varchar(3) NOT NULL,
	  PRIMARY KEY  (id)
	) $charset_collate;";
	
	$sql3 = "CREATE TABLE `{$wpdb->base_prefix}post_viewcounts` (
	  `id` int(11) NOT NULL AUTO_INCREMENT,
	  `post_id` int(11) NOT NULL UNIQUE,
	 `post_parent_id` int(11) NOT NULL,
	  `view_count` int(11) NOT NULL,
	  `last_view_timestamp` int(11) NOT NULL,
	  PRIMARY KEY  (id)
	) $charset_collate;";
	
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($sql);
	dbDelta($sql2);
	dbDelta($sql3);
	
	//Must be connection for Webservice Domain with Mobile App !	
/*
	$response = wp_remote_get( 'http://gungor.online/apps/linker/add_site.php?domain='.get_home_url() );
	if ( is_wp_error( $response ) ) {
	   echo 'There be errors, yo!';
	} else {
	   $body = wp_remote_retrieve_body( $response );
	   $data = json_decode( $body );
	}

	if ( $data->Data ) {
	   print_r( $data->Data );
	}
*/
	
} 	

?>